package com.kdiproductions.explicitintents;

import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class CompanyBase extends AppCompatActivity {

    Button btnAbout, btnWebsite, btnJobListings, btnminimize;
    TextView tvListing1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.company);

        btnAbout = findViewById(R.id.btnAbout);
        btnWebsite = findViewById(R.id.btnWebsite);
        btnJobListings = findViewById(R.id.btnJobListings);
        btnminimize = findViewById(R.id.btnMinimize);

        tvListing1 = findViewById(R.id.tvListing1);


        tvListing1.setVisibility(TextView.GONE);

        btnminimize.setVisibility(View.GONE);

        btnAbout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String listing1 =
                        "Accenture plc, stylised as accenture, is an Irish-domiciled multinational " + "\n"
                                + "professional services company that provides services in strategy, " + "\n"
                                + "consulting, digital, technology and operations.";

                tvListing1.setText(listing1);
                tvListing1.setMovementMethod(new ScrollingMovementMethod());
                btnminimize.setVisibility(View.VISIBLE);
                tvListing1.setVisibility(View.VISIBLE);

            }
        });

        btnWebsite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String listing2 = "https://www.accenture.com/us-en";


                btnminimize.setVisibility(View.VISIBLE);


            }
        });

        btnJobListings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String listing3 = "Internship - Entry Level Technology Associate" + "\n\n"
                +"We’re seeking someone who looks at a problem and knows what " + "\n"
                       + "needs to be done. Even when you don't have all the answers right away, " + "\n"
                        + "you have a sharp mind for figuring things out. You approach challenges " + "\n"
                        + "with balance: teaming up with others and following your own individual motivation."
                        + "\n\n\n\n" +
                        "Full Time - Application Development Sr. Analyst" + "\n"
                        + "is responsible for building and coding Salesforce application " + "\n"
                        + "components using the Force.com platform. Must be capable of " + "\n"
                        + "understanding business requirements, working with end users, " + "\n"
                        + "developing front end functionality and business rules. " + "\n"
                        + "This position ideally requires knowledge with object-oriented " + "\n"
                        + "programming language (ideally Java), databases, web development, " + "\n"
                        + "JavaScript, and HTML. Team leadership, guidance on coding standards," + "\n"
                        + " problem resolution, and project delivery.";


                btnminimize.setVisibility(View.VISIBLE);

            }
        });

        btnminimize.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tvListing1.setVisibility(View.GONE);
                btnminimize.setVisibility(View.GONE);
            }
        });
    }
}




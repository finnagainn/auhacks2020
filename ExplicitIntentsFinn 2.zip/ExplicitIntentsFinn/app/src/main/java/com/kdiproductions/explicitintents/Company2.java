package com.kdiproductions.explicitintents;

import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Company2 extends AppCompatActivity {

    Button btnAbout, btnWebsite, btnJobListings, btnminimize;
    TextView tvListing1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.company2);

        btnAbout = findViewById(R.id.btnAbout);
        btnWebsite = findViewById(R.id.btnWebsite);
        btnJobListings = findViewById(R.id.btnJobListings);
        btnminimize = findViewById(R.id.btnMinimize);

        tvListing1 = findViewById(R.id.tvListing1);


        tvListing1.setVisibility(TextView.GONE);

        btnminimize.setVisibility(View.GONE);

        btnAbout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String listing1 = "Total System Services, Inc., headquartered in Columbus, Georgia, " + "\n"
                       + "provides payment processing services, merchant services " + "\n"
                       + "and related payment services.";

                tvListing1.setText(listing1);
                tvListing1.setMovementMethod(new ScrollingMovementMethod());
                btnminimize.setVisibility(View.VISIBLE);
                tvListing1.setVisibility(View.VISIBLE);

            }
        });

        btnWebsite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String listing2 = "https://www.tsys.com/";


                btnminimize.setVisibility(View.VISIBLE);


            }
        });

        btnJobListings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String listing3 = "Internship - Training Specialist" + "\n\n"
                        + "Develop and deliver training programs on payment processing products," + "\n"
                        + "processes and technologies for both internal and external customers. " + "\n"
                        + "Maintain existing training content and systems resulting from analysis " + "\n"
                        + "of system development, regulatory mandates and/or payment brand compliance. " + "\n"
                        + "Provide presentations, demonstrations, advice and consultancy relating " + "\n"
                        + "to systems and ancillary products. Evaluate to determine if business " + "\n"
                        + "outcomes have been achieved. Follow up to ensure continuous improvement. " + "\n"
                        + "Proactively expand existing and build new knowledge."

                        + "\n\n\n\n"+

                        "Full Time - Full Stack Engineer Digital Innovation Team" + "\n\n"
                        + "We are looking for a Senior, Lead or Architect level Developer" + "\n"
                        + " with experience in Java Stack for our Alpharetta office, " + "\n"
                        + "who can develop the solution from ideation thru production" + "\n"
                        + " rollout with support of junior developers. Role involves" + "\n"
                        + " hands-on development, testing and supporting architects" + "\n"
                        + " and technical leads. In this role, you will work on Products " + "\n"
                        + "that involve Java, Spring Framework, Spring Boot, Spring Cloud," + "\n"
                        + " Microservice Architectures, AWS, REST, JSON, XML, SQL, GraphQL, " + "\n"
                        + "Candidate is expected to handle independent development initiatives" + "\n"
                        + " – including Dev Ops aspects, CI/CD, and Platform - leveraging " + "\n"
                        + "the self-service tools made available by TSYS Framework Teams."

                        + "\n\n\n\n"+

                        "Full Time - Test Specialist" + "\n\n"
                        + "Carry out procedures to ensure that all applications under test (AUT) " + "\n"
                        + "meet organizational standards and end-user requirements. " + "\n"
                        + "Thoroughly test software to ensure proper operation and freedom from defects. " + "\n"
                        + "Document and work to identify all problems to ensure resolution. " + "\n"
                        + "Report progress on testing and problem resolution to appropriate parties. " + "\n"
                        + "Devise improvements to current procedures and develop models " + "\n"
                        + "of possible future configurations. " + "\n"
                        + "Perform work flow analysis and recommends quality improvements.";;


                btnminimize.setVisibility(View.VISIBLE);

            }
        });

        btnminimize.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tvListing1.setVisibility(View.GONE);
                btnminimize.setVisibility(View.GONE);
            }
        });
    }
}




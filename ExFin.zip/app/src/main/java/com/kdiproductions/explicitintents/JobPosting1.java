package com.kdiproductions.explicitintents;

import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class JobPosting1 extends AppCompatActivity {

        Button btnListing1, btnListing2, btnListing3, btnminimize;
        TextView tvListing1, tvListing2, tvListing3;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.jobposting1);

            btnListing1 = findViewById(R.id.btnListing1);
            btnListing2 = findViewById(R.id.btnListing2);
            btnListing3 = findViewById(R.id.btnListing3);
            btnminimize = findViewById(R.id.btnMinimize);

            tvListing1 = findViewById(R.id.tvListing1);
            tvListing2 = findViewById(R.id.tvListing2);
            tvListing3 = findViewById(R.id.tvListing3);

            tvListing1.setVisibility(TextView.GONE);
            tvListing2.setVisibility(TextView.GONE);
            tvListing3.setVisibility(TextView.GONE);
            btnminimize.setVisibility(View.GONE);

            btnListing1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    String listing1 =
                            "What Are We Looking For in This Role? Minimum Qualifications\n" +
                            "BS in Computer Science, Information Technology, Business / Management Information Systems or related field\n" +
                            "Typically minimum of 2 years - Professional Experience In Coding, Designing, Developing And Analyzing Data. Typically has a basic knowledge and use of one or more languages / technologies from the following but not limited to; two or more modern programming languages used in the enterprise, experience working with various APIs, external Services, experience with both relational and NoSQL Databases\n" +
                            "Preferred Qualifications\n" +
                            "BS in Computer Science, Information Technology, Business / Management Information Systems or related field\n" +
                            "4+ years professional Experience In Coding, Designing, Developing And Analyzing Data and experience with IBM Rational Tools\n" +
                            "What Are Our Desired Skills and Capabilities?\n" +
                            "Skills / Knowledge - Developing professional expertise, applies company policies and procedures to resolve a variety of issues.\n" +
                            "Job Complexity - Works on problems of moderate scope where analysis of situations or data requires a review of a variety of factors. Exercises judgment within defined procedures and practices to determine appropriate action. Builds productive internal/external working relationships.\n" +
                            "Supervision - Normally receives general instructions on routine work, detailed instructions on new projects or assignments.\n" +
                            "\n" +
                            "Operating Systems\n" +
                            "Linux distributions including one or more for the following: Ubuntu, CentOS/RHEL, Amazon Linux\n" +
                            "Microsoft Windows\n" +
                            "z/OS\n" +
                            "Tandem/HP-Nonstop\n" +
                            "Database - Design, familiarity with DDL and DML for one or more of the following databases Oracle, MySQL, MS SQL Server, IMS, DB2, Hadoop\n" +
                            "Back-end technologies - Java, Python, .NET, Ruby, Mainframe COBOL, Mainframe Assembler\n" +
                            "Front-end technologies - HTML, JavaScript, jQuery, CICS\n" +
                            "Web Frameworks – Web technologies like Node.js, React.js, Angular, Redux\n" +
                            "Development Tools - Eclipse, Visual Studio, Webpack, Babel, Gulp\n" +
                            "Mobile Development – iOS, Android\n" +
                            "Machine Learning – Python, R, Matlab, Tensorflow, DMTK";

                    tvListing1.setText(listing1);
                    tvListing1.setMovementMethod(new ScrollingMovementMethod());
                    btnminimize.setVisibility(View.VISIBLE);
                    tvListing1.setVisibility(View.VISIBLE);
                    btnListing3.setVisibility(View.GONE);
                    btnListing2.setVisibility(View.GONE);

                }
            });

            btnListing2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    String listing2 = "What Are We Looking For in This Role? Minimum Qualifications\n" +
                            "BS in Computer Science, Information Technology, Business / Management Information Systems or related field\n" +
                            "Typically minimum of 2 years - Professional Experience In Coding, Designing, Developing And Analyzing Data. Typically has a basic knowledge and use of one or more languages / technologies from the following but not limited to; two or more modern programming languages used in the enterprise, experience working with various APIs, external Services, experience with both relational and NoSQL Databases\n" +
                            "Preferred Qualifications\n" +
                            "BS in Computer Science, Information Technology, Business / Management Information Systems or related field\n" +
                            "4+ years professional Experience In Coding, Designing, Developing And Analyzing Data and experience with IBM Rational Tools\n" +
                            "What Are Our Desired Skills and Capabilities?\n" +
                            "Skills / Knowledge - Developing professional expertise, applies company policies and procedures to resolve a variety of issues.\n" +
                            "Job Complexity - Works on problems of moderate scope where analysis of situations or data requires a review of a variety of factors. Exercises judgment within defined procedures and practices to determine appropriate action. Builds productive internal/external working relationships.\n" +
                            "Supervision - Normally receives general instructions on routine work, detailed instructions on new projects or assignments.\n" +
                            "\n" +
                            "Operating Systems\n" +
                            "Linux distributions including one or more for the following: Ubuntu, CentOS/RHEL, Amazon Linux\n" +
                            "Microsoft Windows\n" +
                            "z/OS\n" +
                            "Tandem/HP-Nonstop\n" +
                            "Database - Design, familiarity with DDL and DML for one or more of the following databases Oracle, MySQL, MS SQL Server, IMS, DB2, Hadoop\n" +
                            "Back-end technologies - Java, Python, .NET, Ruby, Mainframe COBOL, Mainframe Assembler\n" +
                            "Front-end technologies - HTML, JavaScript, jQuery, CICS\n" +
                            "Web Frameworks – Web technologies like Node.js, React.js, Angular, Redux\n" +
                            "Development Tools - Eclipse, Visual Studio, Webpack, Babel, Gulp\n" +
                            "Mobile Development – iOS, Android\n" +
                            "Machine Learning – Python, R, Matlab, Tensorflow, DMTK";

                    tvListing2.setText(listing2);
                    btnminimize.setVisibility(View.VISIBLE);
                    tvListing2.setVisibility(View.VISIBLE);
                    btnListing1.setVisibility(View.GONE);
                    btnListing3.setVisibility(View.GONE);

                }
            });

            btnListing3.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    String listing3 = "What Are We Looking For in This Role? Minimum Qualifications\n" +
                            "BS in Computer Science, Information Technology, Business / Management Information Systems or related field\n" +
                            "Typically minimum of 2 years - Professional Experience In Coding, Designing, Developing And Analyzing Data. Typically has a basic knowledge and use of one or more languages / technologies from the following but not limited to; two or more modern programming languages used in the enterprise, experience working with various APIs, external Services, experience with both relational and NoSQL Databases\n" +
                            "Preferred Qualifications\n" +
                            "BS in Computer Science, Information Technology, Business / Management Information Systems or related field\n" +
                            "4+ years professional Experience In Coding, Designing, Developing And Analyzing Data and experience with IBM Rational Tools\n" +
                            "What Are Our Desired Skills and Capabilities?\n" +
                            "Skills / Knowledge - Developing professional expertise, applies company policies and procedures to resolve a variety of issues.\n" +
                            "Job Complexity - Works on problems of moderate scope where analysis of situations or data requires a review of a variety of factors. Exercises judgment within defined procedures and practices to determine appropriate action. Builds productive internal/external working relationships.\n" +
                            "Supervision - Normally receives general instructions on routine work, detailed instructions on new projects or assignments.\n" +
                            "\n" +
                            "Operating Systems\n" +
                            "Linux distributions including one or more for the following: Ubuntu, CentOS/RHEL, Amazon Linux\n" +
                            "Microsoft Windows\n" +
                            "z/OS\n" +
                            "Tandem/HP-Nonstop\n" +
                            "Database - Design, familiarity with DDL and DML for one or more of the following databases Oracle, MySQL, MS SQL Server, IMS, DB2, Hadoop\n" +
                            "Back-end technologies - Java, Python, .NET, Ruby, Mainframe COBOL, Mainframe Assembler\n" +
                            "Front-end technologies - HTML, JavaScript, jQuery, CICS\n" +
                            "Web Frameworks – Web technologies like Node.js, React.js, Angular, Redux\n" +
                            "Development Tools - Eclipse, Visual Studio, Webpack, Babel, Gulp\n" +
                            "Mobile Development – iOS, Android\n" +
                            "Machine Learning – Python, R, Matlab, Tensorflow, DMTK";

                    tvListing3.setText(listing3);
                    btnminimize.setVisibility(View.VISIBLE);
                    tvListing3.setVisibility(View.VISIBLE);
                    btnListing1.setVisibility(View.GONE);
                    btnListing2.setVisibility(View.GONE);

                }
            });

            btnminimize.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    tvListing1.setVisibility(View.GONE);
                    tvListing2.setVisibility(View.GONE);
                    tvListing3.setVisibility(View.GONE);
                    btnListing3.setVisibility(View.VISIBLE);
                    btnListing2.setVisibility(View.VISIBLE);
                    btnListing1.setVisibility(View.VISIBLE);
                    btnminimize.setVisibility(View.GONE);
                }
            });
        }
    }



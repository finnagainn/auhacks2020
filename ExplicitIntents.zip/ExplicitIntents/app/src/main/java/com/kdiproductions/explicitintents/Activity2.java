package com.kdiproductions.explicitintents;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import org.w3c.dom.Text;

public class Activity2 extends AppCompatActivity {


    TextView tvActivity2Welcome;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);

        tvActivity2Welcome = findViewById(R.id.tvActivity2Welcome);

        String name = getIntent().getStringExtra("data"); //it must match the key string in your main act intent

        String welcome = " , Welcome to Activity 2!";

        String output = name + welcome;

        tvActivity2Welcome.setText(output);


    }
}

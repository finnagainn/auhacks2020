package com.kdiproductions.explicitintents;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Activity3 extends AppCompatActivity {

    EditText etAct3Surname;
    Button btnCompany1, btnCompany2, btnCompany3, btnCompany4;
    Button btnCompany5, btnCompany6, btnCompany7;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_3);

        btnCompany1 = findViewById(R.id.btnCompany1);
        btnCompany2 = findViewById(R.id.btnCompany2);
        btnCompany3 = findViewById(R.id.btnCompany3);
        btnCompany4 = findViewById(R.id.btnCompany4);
        btnCompany5 = findViewById(R.id.btnCompany5);
        btnCompany6 = findViewById(R.id.btnCompany6);
        btnCompany7 = findViewById(R.id.btnCompany7);


        btnCompany1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(Activity3.this,  // this intent moves you from main activity to act3
                        com.kdiproductions.explicitintents.Company1.class);

                startActivity(intent);

            }
        });
        btnCompany2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(Activity3.this,  // this intent moves you from main activity to act3
                        com.kdiproductions.explicitintents.Company2.class);

                startActivity(intent);

            }
        });
        btnCompany3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(Activity3.this,  // this intent moves you from main activity to act3
                        com.kdiproductions.explicitintents.Company3.class);

                startActivity(intent);

            }
        });
        btnCompany4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(Activity3.this,  // this intent moves you from main activity to act3
                        com.kdiproductions.explicitintents.Company4.class);

                startActivity(intent);

            }
        });
        btnCompany5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(Activity3.this,  // this intent moves you from main activity to act3
                        com.kdiproductions.explicitintents.Company5.class);

                startActivity(intent);

            }
        });
        btnCompany6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(Activity3.this,  // this intent moves you from main activity to act3
                        com.kdiproductions.explicitintents.Company6.class);

                startActivity(intent);

            }
        });
        btnCompany7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(Activity3.this,  // this intent moves you from main activity to act3
                        com.kdiproductions.explicitintents.Company7.class);

                startActivity(intent);

            }
        });


    /**
        etAct3Surname = findViewById(R.id.etAct3Surname);
        btnAct3Submit = findViewById(R.id.btnAct3Submit);
        btnCancel = findViewById(R.id.btnCancel);

        btnAct3Submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (etAct3Surname.getText().toString().isEmpty()) {
                    Toast.makeText(com.kdiproductions.explicitintents.Activity3.this, "Please enter all fields!",
                            Toast.LENGTH_SHORT).show();
                }
                else
                {
                    String surname = etAct3Surname.getText().toString().trim();

                    Intent intent = new Intent(); // we are only passing back data in this case
                    intent.putExtra("surnamedata", surname);

                    setResult(RESULT_OK, intent);

                    Activity3.this.finish();

                }
            }


            });

        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setResult(RESULT_CANCELED);
                Activity3.this.finish();
            }
        });

     */
    }

}





package com.kdiproductions.explicitintents;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;



public class Events extends AppCompatActivity {
    Button btnAct1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.events);

        btnAct1 = findViewById(R.id.btnAct1);


        btnAct1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(Events.this,  // this intent moves you from main activity to act3
                        com.kdiproductions.explicitintents.Activity3.class);

                startActivity(intent);

            }
        });
    }
}

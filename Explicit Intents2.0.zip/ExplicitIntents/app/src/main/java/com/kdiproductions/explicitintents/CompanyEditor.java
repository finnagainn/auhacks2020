package com.kdiproductions.explicitintents;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class CompanyEditor extends AppCompatActivity {


    private static int RESULT_LOAD_IMAGE = 1;
    EditText etLinkWebsite, etLinkJobs, etCompanyName, etDesc;
    String linkWeb, linkJobs, compName, compDesc;
    Button submit;
    ImageView imageView;



    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.companyeditor);
        etLinkWebsite = findViewById(R.id.etLinkWebsite);
        etLinkJobs = findViewById(R.id.etLinkJobs);
        etCompanyName = findViewById(R.id.etCompanyName);
        etDesc = findViewById(R.id.etDesc);
        submit = findViewById(R.id.btnSubmit);

        Button buttonLoadImage = (Button) findViewById(R.id.buttonLoadPicture);
        buttonLoadImage.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {

                Intent i = new Intent(
                        Intent.ACTION_PICK,
                        android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);

                startActivityForResult(i, RESULT_LOAD_IMAGE);
            }
        });

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                linkWeb = etLinkWebsite.getText().toString();
                linkJobs = etLinkJobs.getText().toString();
                compName = etCompanyName.getText().toString();
                compDesc = etDesc.getText().toString();

                if(linkWeb.isEmpty() || linkJobs.isEmpty() || compName.isEmpty() || compDesc.isEmpty()){
                    Toast.makeText(CompanyEditor.this, "Please Enter all Fields!", Toast.LENGTH_SHORT).show();
                }
                else {
                    String firstInput = compName;
                    String secondInput = compDesc;
                    String thirdInput = linkJobs;
                    String fourthInput = linkWeb;

                    Intent inte = new Intent (CompanyEditor.this, CompanyEditedVersion.class);
                    inte.putExtra("name", firstInput);
                    inte.putExtra("desc", secondInput);
                    inte.putExtra("jobs", thirdInput);
                    inte.putExtra("website", fourthInput);

                    startActivity(inte);



                }
            }
        });
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == RESULT_LOAD_IMAGE && resultCode == RESULT_OK && null != data) {
            Uri selectedImage = data.getData();
            String[] filePathColumn = { MediaStore.Images.Media.DATA };

            Cursor cursor = getContentResolver().query(selectedImage,
                    filePathColumn, null, null, null);
            cursor.moveToFirst();

            int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
            String picturePath = cursor.getString(columnIndex);
            cursor.close();

            imageView = (ImageView) findViewById(R.id.imgView44);
            imageView.setImageBitmap(BitmapFactory.decodeFile(picturePath));

        }


    }
}